import { Platform } from '../types/Platform';

export const platforms: Platform[] = [
  {
    id: 'amazon',
    name: 'Amazon',
    logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Amazon_logo.svg/2560px-Amazon_logo.svg.png'
  },
  {
    id: 'flipkart',
    name: 'Flipkart',
    logoUrl: 'https://logos-world.net/wp-content/uploads/2020/11/Flipkart-Logo.png'
  },
  {
    id: 'myntra',
    name: 'Myntra',
    logoUrl: 'https://logos-download.com/wp-content/uploads/2016/09/Myntra_logo-1.png'
  },
  {
    id: 'meesho',
    name: 'Meesho',
    logoUrl: 'https://images.squarespace-cdn.com/content/v1/57d841db1b631b999a764625/1593747707216-4CFL6T9ABPWI1EL2WU1G/Meesho+logo.png'
  },
  {
    id: 'snapdeal',
    name: 'Snapdeal',
    logoUrl: 'https://logos-download.com/wp-content/uploads/2016/10/SnapDeal_logo_logotype.png'
  },
  {
    id: 'ajio',
    name: 'Ajio',
    logoUrl: 'https://assets.ajio.com/static/img/Ajio-Logo.svg'
  }
];