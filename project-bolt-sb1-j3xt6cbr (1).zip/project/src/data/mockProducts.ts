import { Product } from '../types/Product';
import { platforms } from './platforms';

// Helper function to find platform by ID
const getPlatform = (id: string) => {
  return platforms.find(platform => platform.id === id) || platforms[0];
};

export const trendingProducts: Product[] = [
  {
    id: 'smartphone-001',
    name: 'iPhone 13 (128GB) - Midnight',
    description: 'The iPhone 13 features a 6.1-inch Super Retina XDR display, A15 Bionic chip, and an advanced dual-camera system.',
    images: [
      'https://images.pexels.com/photos/5750001/pexels-photo-5750001.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/5750001/pexels-photo-5750001.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/5750001/pexels-photo-5750001.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    ],
    rating: 4.5,
    reviews: 3258,
    mrp: 69900,
    highlights: [
      '15.4 cm (6.1-inch) Super Retina XDR display',
      'A15 Bionic chip for lightning-fast performance',
      'Advanced dual-camera system with 12MP Wide and Ultra Wide cameras',
      'Cinematic mode adds shallow depth of field and shifts focus automatically',
      'Up to 19 hours of video playback'
    ],
    priceListings: [
      {
        price: 52999,
        platform: getPlatform('amazon'),
        productUrl: '#',
        delivery: 'Free delivery by tomorrow',
        inStock: true
      },
      {
        price: 53999,
        platform: getPlatform('flipkart'),
        productUrl: '#',
        delivery: 'Delivery in 2 days',
        inStock: true
      },
      {
        price: 54490,
        platform: getPlatform('myntra'),
        productUrl: '#',
        delivery: 'Delivery in 3-4 days',
        inStock: true
      }
    ]
  },
  {
    id: 'laptop-001',
    name: 'HP Pavilion 15 Laptop, 11th Gen Intel Core i5-1135G7, 16 GB RAM, 512 GB SSD',
    description: 'Stay connected to what matters most with long-lasting battery life and a sleek, portable design. Perfect for productivity.',
    images: [
      'https://images.pexels.com/photos/7974/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/7974/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/7974/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    ],
    rating: 4.3,
    reviews: 1847,
    mrp: 76990,
    highlights: [
      '11th Generation Intel Core i5-1135G7 processor',
      '15.6" diagonal, FHD (1920 x 1080), IPS, anti-glare display',
      '16 GB DDR4-3200 SDRAM memory',
      '512 GB PCIe NVMe M.2 SSD storage',
      'Intel Iris Xe Graphics',
      'Battery life up to 8 hours'
    ],
    priceListings: [
      {
        price: 59990,
        platform: getPlatform('amazon'),
        productUrl: '#',
        delivery: 'Free delivery in 2 days',
        inStock: true
      },
      {
        price: 58499,
        platform: getPlatform('flipkart'),
        productUrl: '#',
        delivery: 'Delivery in 3 days',
        inStock: true
      },
      {
        price: 62999,
        platform: getPlatform('snapdeal'),
        productUrl: '#',
        delivery: 'Delivery in 4-5 days',
        inStock: true
      }
    ]
  },
  {
    id: 'watch-001',
    name: 'Noise ColorFit Pro 3 Smartwatch with 1.55" HD Display, 10-Day Battery',
    description: 'Noise ColorFit Pro 3 is the smartwatch that has got it all. Track your vitals, manage calls, and train with 14 sports modes.',
    images: [
      'https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    ],
    rating: 4.1,
    reviews: 13522,
    mrp: 5999,
    highlights: [
      '1.55" HD TruView Display',
      'SpO2, heart rate, sleep & stress monitor',
      '14 sports modes',
      '10-day battery life',
      'IP68 water resistance'
    ],
    priceListings: [
      {
        price: 2799,
        platform: getPlatform('amazon'),
        productUrl: '#',
        delivery: 'Free delivery tomorrow',
        inStock: true
      },
      {
        price: 2999,
        platform: getPlatform('flipkart'),
        productUrl: '#',
        delivery: 'Delivery in 2 days',
        inStock: true
      },
      {
        price: 3299,
        platform: getPlatform('myntra'),
        productUrl: '#',
        delivery: 'Delivery in 3 days',
        inStock: true
      },
      {
        price: 2699,
        platform: getPlatform('meesho'),
        productUrl: '#',
        delivery: 'Delivery in 4 days',
        inStock: true
      }
    ]
  },
  {
    id: 'headphone-001',
    name: 'boAt Rockerz 550 Bluetooth Wireless Over Ear Headphones with Mic',
    description: 'boAt Rockerz 550 is an over-ear wireless headset that has been ergonomically designed to meet the needs of music lovers.',
    images: [
      'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    ],
    rating: 4.2,
    reviews: 8763,
    mrp: 4999,
    highlights: [
      'Bluetooth version 5.0 with a range of 10m',
      'Up to 20 hours of playback',
      '50mm dynamic drivers for immersive sound',
      'Soft padded ear cushions and adjustable headband',
      'Quick charge - 10 minutes for 3 hours playback'
    ],
    priceListings: [
      {
        price: 1799,
        platform: getPlatform('amazon'),
        productUrl: '#',
        delivery: 'Free delivery tomorrow',
        inStock: true
      },
      {
        price: 1849,
        platform: getPlatform('flipkart'),
        productUrl: '#',
        delivery: 'Free delivery in 2 days',
        inStock: true
      },
      {
        price: 1999,
        platform: getPlatform('snapdeal'),
        productUrl: '#',
        delivery: 'Delivery in 3 days',
        inStock: true
      }
    ]
  },
  {
    id: 'camera-001',
    name: 'Canon EOS 1500D 24.1 Digital SLR Camera with EF S18-55 IS II Lens',
    description: 'The Canon EOS 1500D camera produces high-quality images with its 24.1 MP sensor and Full HD video recording capabilities.',
    images: [
      'https://images.pexels.com/photos/51383/photo-camera-subject-photographer-51383.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/51383/photo-camera-subject-photographer-51383.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/51383/photo-camera-subject-photographer-51383.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    ],
    rating: 4.4,
    reviews: 5421,
    mrp: 39995,
    highlights: [
      '24.1MP APS-C CMOS sensor & DIGIC 4+ image processor',
      'Full HD video with fully manual control and selectable frame rates',
      '9-point AF with 1 center cross-type AF point',
      'Built-in Wi-Fi and NFC technology',
      'Scene Intelligent Auto mode'
    ],
    priceListings: [
      {
        price: 33990,
        platform: getPlatform('amazon'),
        productUrl: '#',
        delivery: 'Free delivery in 2 days',
        inStock: true
      },
      {
        price: 33499,
        platform: getPlatform('flipkart'),
        productUrl: '#',
        delivery: 'Delivery in 3 days',
        inStock: true
      },
      {
        price: 34990,
        platform: getPlatform('snapdeal'),
        productUrl: '#',
        delivery: 'Delivery in 4-5 days',
        inStock: true
      }
    ]
  },
  {
    id: 'shirt-001',
    name: 'Allen Solly Men Regular Fit Formal Shirt',
    description: 'A classic formal shirt for men by Allen Solly that combines comfort with style, perfect for office wear or formal occasions.',
    images: [
      'https://images.pexels.com/photos/297933/pexels-photo-297933.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/297933/pexels-photo-297933.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/297933/pexels-photo-297933.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    ],
    rating: 4.0,
    reviews: 3245,
    mrp: 1999,
    highlights: [
      'Regular fit',
      '100% Premium Cotton',
      'Button-down collar',
      'Full sleeves with button cuffs',
      'Machine wash'
    ],
    priceListings: [
      {
        price: 999,
        platform: getPlatform('amazon'),
        productUrl: '#',
        delivery: 'Delivery in 2 days',
        inStock: true
      },
      {
        price: 879,
        platform: getPlatform('myntra'),
        productUrl: '#',
        delivery: 'Free delivery in 3 days',
        inStock: true
      },
      {
        price: 949,
        platform: getPlatform('ajio'),
        productUrl: '#',
        delivery: 'Delivery in 3 days',
        inStock: true
      },
      {
        price: 1099,
        platform: getPlatform('flipkart'),
        productUrl: '#',
        delivery: 'Delivery in 2 days',
        inStock: true
      }
    ]
  },
  {
    id: 'mixer-001',
    name: 'Bajaj Rex 500W Mixer Grinder with 3 Jars',
    description: 'The Bajaj Rex Mixer Grinder is a powerful kitchen appliance with multifunctional capabilities for all your grinding needs.',
    images: [
      'https://images.pexels.com/photos/1080719/pexels-photo-1080719.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/1080719/pexels-photo-1080719.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/1080719/pexels-photo-1080719.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    ],
    rating: 4.2,
    reviews: 12587,
    mrp: 3695,
    highlights: [
      '500 watts powerful motor',
      '3 stainless steel jars - liquidizing, grinding and chutney',
      'Multi-function blade system',
      '3-speed control with incher',
      '2-year manufacturer warranty'
    ],
    priceListings: [
      {
        price: 2099,
        platform: getPlatform('amazon'),
        productUrl: '#',
        delivery: 'Free delivery tomorrow',
        inStock: true
      },
      {
        price: 1949,
        platform: getPlatform('flipkart'),
        productUrl: '#',
        delivery: 'Delivery in 2 days',
        inStock: true
      },
      {
        price: 2150,
        platform: getPlatform('snapdeal'),
        productUrl: '#',
        delivery: 'Delivery in 3-4 days',
        inStock: true
      }
    ]
  },
  {
    id: 'sneaker-001',
    name: 'Nike Air Zoom Pegasus 38 Running Shoes',
    description: 'The Nike Air Zoom Pegasus 38 is designed to keep you on the run with the same cushioned support as its predecessor.',
    images: [
      'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    ],
    rating: 4.6,
    reviews: 4867,
    mrp: 9995,
    highlights: [
      'Nike React foam midsole for responsive cushioning',
      'Mesh upper for breathability',
      'Zoom Air unit in the forefoot for responsive cushioning',
      'Wider forefoot for more toe room',
      'Midfoot band adapts to your foot for a snug fit'
    ],
    priceListings: [
      {
        price: 7495,
        platform: getPlatform('amazon'),
        productUrl: '#',
        delivery: 'Free delivery in 2 days',
        inStock: true
      },
      {
        price: 6999,
        platform: getPlatform('myntra'),
        productUrl: '#',
        delivery: 'Free delivery in 3 days',
        inStock: true
      },
      {
        price: 7999,
        platform: getPlatform('ajio'),
        productUrl: '#',
        delivery: 'Delivery in 2-3 days',
        inStock: true
      }
    ]
  }
];