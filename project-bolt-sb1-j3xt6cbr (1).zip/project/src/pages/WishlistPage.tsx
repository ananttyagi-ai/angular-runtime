import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Heart, Search, Trash2, ChevronRight, AlertTriangle } from 'lucide-react';
import { useWishlist } from '../context/WishlistContext';
import PriceComparisonCard from '../components/products/PriceComparisonCard';

const WishlistPage: React.FC = () => {
  const { wishlist, removeFromWishlist, clearWishlist } = useWishlist();
  const [searchQuery, setSearchQuery] = useState('');
  
  // Filter wishlist items by search term
  const filteredWishlist = wishlist.filter(item => 
    item.name.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-2xl font-bold flex items-center">
            <Heart className="w-6 h-6 text-red-500 mr-2" />
            My Wishlist
          </h1>
          <p className="text-gray-600 mt-1">
            {wishlist.length} {wishlist.length === 1 ? 'item' : 'items'} saved
          </p>
        </div>
        
        {wishlist.length > 0 && (
          <div className="flex items-center gap-4 w-full md:w-auto">
            <div className="relative flex-grow md:w-64">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Search in wishlist"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              />
            </div>
            
            <button 
              onClick={() => {
                if (confirm('Are you sure you want to clear your wishlist?')) {
                  clearWishlist();
                }
              }}
              className="text-red-500 hover:text-red-600 text-sm font-medium"
            >
              Clear All
            </button>
          </div>
        )}
      </div>
      
      {/* Breadcrumbs */}
      <div className="flex items-center text-sm text-gray-500 mb-6">
        <Link to="/" className="hover:text-orange-500">Home</Link>
        <ChevronRight className="w-4 h-4 mx-1" />
        <span className="text-gray-700">My Wishlist</span>
      </div>
      
      {wishlist.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-lg shadow-sm border">
          <div className="w-20 h-20 mx-auto flex items-center justify-center rounded-full bg-gray-100">
            <Heart className="w-10 h-10 text-gray-400" />
          </div>
          <h2 className="mt-4 text-xl font-semibold">Your wishlist is empty</h2>
          <p className="mt-2 text-gray-600 max-w-md mx-auto">
            Start saving your favorite products to track prices and get the best deals!
          </p>
          <Link 
            to="/" 
            className="mt-6 inline-block px-6 py-3 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition"
          >
            Discover Products
          </Link>
        </div>
      ) : filteredWishlist.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg shadow-sm border">
          <AlertTriangle className="w-12 h-12 text-orange-500 mx-auto" />
          <h2 className="mt-4 text-lg font-semibold">No matches found</h2>
          <p className="mt-2 text-gray-600 max-w-md mx-auto">
            No products in your wishlist match "{searchQuery}"
          </p>
          <button 
            onClick={() => setSearchQuery('')}
            className="mt-4 text-orange-500 hover:text-orange-600"
          >
            Clear search
          </button>
        </div>
      ) : (
        <div className="space-y-6">
          {filteredWishlist.map(product => (
            <div key={product.id} className="relative">
              <PriceComparisonCard product={product} />
              <button
                onClick={() => removeFromWishlist(product.id)}
                className="absolute top-4 right-4 p-2 bg-white rounded-full border shadow-sm hover:shadow text-gray-500 hover:text-red-500 transition"
                aria-label="Remove from wishlist"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default WishlistPage;