import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { Filter, SlidersHorizontal, X } from 'lucide-react';
import ProductCard from '../components/products/ProductCard';
import FilterSidebar from '../components/filters/FilterSidebar';
import { searchProducts } from '../utils/productApi';
import { Product } from '../types/Product';
import { platforms } from '../data/platforms';
import PriceComparisonCard from '../components/products/PriceComparisonCard';

const SearchResultsPage: React.FC = () => {
  const location = useLocation();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [showFilters, setShowFilters] = useState(false);
  const [activeFilters, setActiveFilters] = useState<{
    platforms: string[],
    priceRange: [number, number] | null,
    sortBy: string
  }>({
    platforms: [],
    priceRange: null,
    sortBy: 'bestMatch'
  });
  
  const query = new URLSearchParams(location.search).get('q') || '';
  
  // Fetch search results
  useEffect(() => {
    const fetchResults = async () => {
      setLoading(true);
      
      try {
        // Simulate API call delay
        const results = await searchProducts(query, activeFilters);
        setProducts(results);
      } catch (error) {
        console.error('Error fetching search results:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchResults();
  }, [query, activeFilters]);
  
  // Handle filter changes
  const applyFilters = (filters: typeof activeFilters) => {
    setActiveFilters(filters);
  };
  
  // Clear single filter
  const clearFilter = (filterType: keyof typeof activeFilters, value?: string) => {
    if (filterType === 'platforms' && value) {
      setActiveFilters({
        ...activeFilters,
        platforms: activeFilters.platforms.filter(p => p !== value)
      });
    } else if (filterType === 'priceRange') {
      setActiveFilters({
        ...activeFilters,
        priceRange: null
      });
    } else if (filterType === 'sortBy') {
      setActiveFilters({
        ...activeFilters,
        sortBy: 'bestMatch'
      });
    }
  };
  
  // Clear all filters
  const clearAllFilters = () => {
    setActiveFilters({
      platforms: [],
      priceRange: null,
      sortBy: 'bestMatch'
    });
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col space-y-4">
        {/* Search query header */}
        <div>
          <h1 className="text-2xl font-bold">Search Results for "{query}"</h1>
          <p className="text-gray-600 mt-1">
            {loading ? 'Searching...' : `Found ${products.length} products`}
          </p>
        </div>
        
        {/* Active filters */}
        {(activeFilters.platforms.length > 0 || activeFilters.priceRange || activeFilters.sortBy !== 'bestMatch') && (
          <div className="flex flex-wrap items-center gap-2 bg-gray-50 p-3 rounded-lg">
            <span className="text-sm font-medium text-gray-700">Active Filters:</span>
            
            {activeFilters.platforms.map(platformId => {
              const platform = platforms.find(p => p.id === platformId);
              return platform ? (
                <div key={platformId} className="inline-flex items-center bg-white px-3 py-1 rounded-full border text-sm">
                  <img src={platform.logoUrl} alt={platform.name} className="w-4 h-4 mr-1" />
                  <span>{platform.name}</span>
                  <button 
                    onClick={() => clearFilter('platforms', platformId)}
                    className="ml-1 text-gray-500 hover:text-gray-700"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ) : null;
            })}
            
            {activeFilters.priceRange && (
              <div className="inline-flex items-center bg-white px-3 py-1 rounded-full border text-sm">
                <span>₹{activeFilters.priceRange[0]} - ₹{activeFilters.priceRange[1]}</span>
                <button 
                  onClick={() => clearFilter('priceRange')}
                  className="ml-1 text-gray-500 hover:text-gray-700"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            )}
            
            {activeFilters.sortBy !== 'bestMatch' && (
              <div className="inline-flex items-center bg-white px-3 py-1 rounded-full border text-sm">
                <span>
                  {activeFilters.sortBy === 'priceLowToHigh' ? 'Price: Low to High' : 
                   activeFilters.sortBy === 'priceHighToLow' ? 'Price: High to Low' : 
                   activeFilters.sortBy === 'newest' ? 'Newest First' : activeFilters.sortBy}
                </span>
                <button 
                  onClick={() => clearFilter('sortBy')}
                  className="ml-1 text-gray-500 hover:text-gray-700"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            )}
            
            <button 
              onClick={clearAllFilters}
              className="text-orange-500 text-sm font-medium hover:text-orange-600 ml-auto"
            >
              Clear All
            </button>
          </div>
        )}
      </div>
      
      <div className="flex flex-col md:flex-row gap-6 mt-6">
        {/* Filters sidebar */}
        <aside className={`md:w-64 flex-shrink-0 transition-all duration-300 ${showFilters ? 'block' : 'hidden md:block'}`}>
          <FilterSidebar 
            activeFilters={activeFilters}
            onApplyFilters={applyFilters}
            onClose={() => setShowFilters(false)}
          />
        </aside>
        
        {/* Main content */}
        <div className="flex-grow">
          {/* Mobile filter button */}
          <div className="md:hidden mb-4">
            <button 
              onClick={() => setShowFilters(true)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-white flex items-center justify-center gap-2 text-gray-700"
            >
              <SlidersHorizontal className="w-5 h-5" />
              <span>Filters & Sort</span>
            </button>
          </div>
          
          {/* Loading state */}
          {loading ? (
            <div className="h-60 flex flex-col items-center justify-center">
              <div className="w-12 h-12 border-4 border-gray-200 border-t-orange-500 rounded-full animate-spin"></div>
              <p className="mt-4 text-gray-600">Searching across platforms...</p>
            </div>
          ) : products.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-gray-400 mb-4">
                <Filter className="w-16 h-16 mx-auto" />
              </div>
              <h2 className="text-xl font-semibold mb-2">No results found</h2>
              <p className="text-gray-600">
                Try adjusting your search or filter criteria to find what you're looking for.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-6">
              {products.map(product => (
                <PriceComparisonCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SearchResultsPage;