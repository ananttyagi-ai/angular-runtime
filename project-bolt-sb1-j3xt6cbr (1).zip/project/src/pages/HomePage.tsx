import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, TrendingUp, Tag, Clock, ShieldCheck } from 'lucide-react';
import SearchBar from '../components/search/SearchBar';
import { platforms } from '../data/platforms';
import { categories } from '../data/categories';
import { trendingProducts } from '../data/mockProducts';
import ProductCard from '../components/products/ProductCard';

const HomePage: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  return (
    <div className="space-y-12 pb-12">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-900 to-indigo-800 text-white">
        <div className="container mx-auto px-4 py-16 md:py-24">
          <div className="text-center max-w-4xl mx-auto space-y-6">
            <h1 className="text-3xl md:text-5xl font-bold leading-tight">
              Compare Prices Across All Major Indian Shopping Sites
            </h1>
            <p className="text-lg md:text-xl opacity-90 max-w-3xl mx-auto">
              Find the best deals on Amazon, Flipkart, Myntra, and more - all in one place!
            </p>
            <div className="max-w-2xl mx-auto pt-4">
              <SearchBar 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onSubmit={handleSearch}
                placeholder="Search for mobile phones, laptops, fashion..."
              />
            </div>
          </div>
        </div>
      </section>

      {/* Supported Platforms */}
      <section className="container mx-auto px-4">
        <h2 className="text-2xl font-bold text-center mb-8">Compare Prices Across These Platforms</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4 items-center justify-items-center">
          {platforms.map((platform) => (
            <div key={platform.id} className="p-4 rounded-lg bg-white shadow-sm hover:shadow-md transition-shadow flex items-center justify-center h-20 w-full">
              <img 
                src={platform.logoUrl} 
                alt={platform.name} 
                className="max-h-10 max-w-full object-contain" 
              />
            </div>
          ))}
        </div>
      </section>

      {/* Benefits */}
      <section className="bg-gray-50 py-12">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-center mb-10">Why Use IndiaShopHub?</h2>
          <div className="grid md:grid-cols-4 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition text-center">
              <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-orange-100 text-orange-500 mb-4">
                <Search className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-semibold mb-2">One Search, All Sites</h3>
              <p className="text-gray-600">Search once and compare prices across all major Indian shopping sites.</p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition text-center">
              <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-blue-100 text-blue-500 mb-4">
                <Tag className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Best Price Guaranteed</h3>
              <p className="text-gray-600">Find the lowest prices and best deals available online.</p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition text-center">
              <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-green-100 text-green-500 mb-4">
                <Clock className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Save Time & Effort</h3>
              <p className="text-gray-600">No more switching between multiple apps and websites.</p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition text-center">
              <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-purple-100 text-purple-500 mb-4">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Price Drop Alerts</h3>
              <p className="text-gray-600">Get notified when prices drop on your favorite products.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Popular Categories */}
      <section className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8">
          <h2 className="text-2xl font-bold">Popular Categories</h2>
          <a href="#" className="text-orange-500 hover:text-orange-600 mt-2 md:mt-0">View All Categories</a>
        </div>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {categories.slice(0, 6).map((category) => (
            <a 
              key={category.id} 
              href="#" 
              className="group bg-white rounded-lg shadow hover:shadow-md transition overflow-hidden border border-gray-100"
            >
              <div className="aspect-square relative overflow-hidden">
                <img 
                  src={category.imageUrl} 
                  alt={category.name} 
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-300" 
                />
              </div>
              <div className="p-3 text-center">
                <h3 className="font-medium">{category.name}</h3>
              </div>
            </a>
          ))}
        </div>
      </section>

      {/* Trending Products */}
      <section className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8">
          <div className="flex items-center">
            <TrendingUp className="w-6 h-6 text-orange-500 mr-2" />
            <h2 className="text-2xl font-bold">Trending Products</h2>
          </div>
          <a href="#" className="text-orange-500 hover:text-orange-600 mt-2 md:mt-0">View All Trending</a>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {trendingProducts.slice(0, 8).map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* Newsletter */}
      <section className="bg-orange-500 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-2xl mx-auto space-y-6">
            <h2 className="text-2xl md:text-3xl font-bold">Get Exclusive Deals And Price Alerts</h2>
            <p className="opacity-90">Subscribe to our newsletter and be the first to know about the best deals.</p>
            <form className="flex flex-col sm:flex-row gap-2 mt-4">
              <input 
                type="email" 
                placeholder="Enter your email address" 
                className="px-4 py-3 rounded-md flex-grow text-gray-900 focus:outline-none focus:ring-2 focus:ring-orange-300" 
              />
              <button className="px-6 py-3 bg-gray-900 text-white rounded-md hover:bg-gray-800 transition focus:outline-none focus:ring-2 focus:ring-gray-700">
                Subscribe
              </button>
            </form>
            <p className="text-sm opacity-75">We respect your privacy. Unsubscribe at any time.</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;