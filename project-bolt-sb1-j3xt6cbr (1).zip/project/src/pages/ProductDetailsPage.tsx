import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Star, Heart, Share2, ExternalLink, ChevronRight, Info, ShieldCheck, Truck } from 'lucide-react';
import { getProductById } from '../utils/productApi';
import { Product } from '../types/Product';
import { useWishlist } from '../context/WishlistContext';

const ProductDetailsPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState<string>('');
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();
  
  useEffect(() => {
    const fetchProduct = async () => {
      if (!id) return;
      
      setLoading(true);
      try {
        const productData = await getProductById(id);
        setProduct(productData);
        if (productData.images && productData.images.length > 0) {
          setSelectedImage(productData.images[0]);
        }
      } catch (error) {
        console.error('Error fetching product:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchProduct();
  }, [id]);
  
  if (loading) {
    return (
      <div className="container mx-auto px-4 py-12 flex justify-center">
        <div className="w-12 h-12 border-4 border-gray-200 border-t-orange-500 rounded-full animate-spin"></div>
      </div>
    );
  }
  
  if (!product) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h2 className="text-2xl font-bold mb-4">Product Not Found</h2>
        <p className="mb-6">The product you're looking for doesn't exist or has been removed.</p>
        <Link to="/" className="inline-block px-6 py-3 bg-orange-500 text-white rounded-lg">
          Return to Home
        </Link>
      </div>
    );
  }
  
  const inWishlist = isInWishlist(product.id);
  
  const toggleWishlist = () => {
    if (inWishlist) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist(product);
    }
  };
  
  // Sort price listings by price (lowest first)
  const sortedPriceListings = [...product.priceListings].sort((a, b) => a.price - b.price);
  const lowestPrice = sortedPriceListings[0];
  
  return (
    <div className="container mx-auto px-4 py-8">
      {/* Breadcrumbs */}
      <div className="flex items-center text-sm text-gray-500 mb-6">
        <Link to="/" className="hover:text-orange-500">Home</Link>
        <ChevronRight className="w-4 h-4 mx-1" />
        <Link to="/search" className="hover:text-orange-500">Search</Link>
        <ChevronRight className="w-4 h-4 mx-1" />
        <span className="text-gray-700 truncate max-w-xs">{product.name}</span>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        {/* Product Images */}
        <div className="space-y-4">
          <div className="bg-white rounded-lg border p-4 overflow-hidden">
            <img 
              src={selectedImage || product.images[0]} 
              alt={product.name} 
              className="w-full h-auto object-contain aspect-square" 
            />
          </div>
          
          {product.images.length > 1 && (
            <div className="grid grid-cols-5 gap-2">
              {product.images.map((image, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedImage(image)}
                  className={`border p-1 rounded-md hover:border-orange-500 transition ${selectedImage === image ? 'border-orange-500' : 'border-gray-200'}`}
                >
                  <img src={image} alt={`${product.name} - view ${index + 1}`} className="w-full h-auto aspect-square object-contain" />
                </button>
              ))}
            </div>
          )}
        </div>
        
        {/* Product Info */}
        <div className="space-y-6">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold mb-2">{product.name}</h1>
            
            <div className="flex items-center gap-4 text-sm">
              <div className="flex items-center">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star 
                    key={i} 
                    className={`w-4 h-4 ${i < Math.floor(product.rating) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
                  />
                ))}
                <span className="ml-1 text-gray-600">{product.rating.toFixed(1)}</span>
              </div>
              <span className="text-gray-500">({product.reviews} reviews)</span>
            </div>
          </div>
          
          {/* Best Price */}
          <div className="bg-green-50 border border-green-100 rounded-lg p-4">
            <div className="flex justify-between items-start">
              <div>
                <div className="flex items-center">
                  <span className="text-sm font-medium text-green-700">Best Price</span>
                  <ShieldCheck className="w-4 h-4 text-green-600 ml-1" />
                </div>
                <div className="mt-1 flex items-baseline">
                  <span className="text-3xl font-bold text-gray-900">₹{lowestPrice.price.toLocaleString()}</span>
                  {product.mrp && (
                    <>
                      <span className="ml-2 text-sm text-gray-500 line-through">₹{product.mrp.toLocaleString()}</span>
                      <span className="ml-2 text-sm font-medium text-green-600">
                        {Math.round(((product.mrp - lowestPrice.price) / product.mrp) * 100)}% off
                      </span>
                    </>
                  )}
                </div>
                <div className="mt-1 flex items-center">
                  <img 
                    src={lowestPrice.platform.logoUrl} 
                    alt={lowestPrice.platform.name} 
                    className="h-5 w-auto mr-2" 
                  />
                  <span className="text-sm text-gray-600">on {lowestPrice.platform.name}</span>
                </div>
              </div>
              
              <a 
                href={lowestPrice.productUrl} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="bg-orange-500 hover:bg-orange-600 text-white px-5 py-3 rounded-lg flex items-center transition"
              >
                <span>Buy Now</span>
                <ExternalLink className="w-4 h-4 ml-1" />
              </a>
            </div>
          </div>
          
          {/* Action Buttons */}
          <div className="flex gap-4">
            <button 
              onClick={toggleWishlist}
              className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 border rounded-lg transition ${inWishlist ? 'bg-red-50 border-red-100 text-red-500' : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'}`}
            >
              <Heart className={`w-5 h-5 ${inWishlist ? 'fill-red-500' : ''}`} />
              <span>{inWishlist ? 'Saved' : 'Save'}</span>
            </button>
            
            <button className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-white border border-gray-200 rounded-lg text-gray-700 hover:bg-gray-50 transition">
              <Share2 className="w-5 h-5" />
              <span>Share</span>
            </button>
          </div>
          
          {/* Key Details */}
          <div className="space-y-3 text-sm border-t border-b py-4">
            {product.highlights.map((highlight, index) => (
              <div key={index} className="flex gap-2">
                <div className="text-orange-500 mt-0.5">
                  <Info className="w-4 h-4" />
                </div>
                <span>{highlight}</span>
              </div>
            ))}
          </div>
          
          {/* All Price Listings */}
          <div>
            <h3 className="text-lg font-semibold mb-4">All Price Listings</h3>
            <div className="space-y-3">
              {sortedPriceListings.map((listing, index) => (
                <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <img 
                      src={listing.platform.logoUrl} 
                      alt={listing.platform.name} 
                      className="h-8 w-auto" 
                    />
                    <div>
                      <div className="font-semibold">₹{listing.price.toLocaleString()}</div>
                      {listing.delivery && (
                        <div className="text-xs text-gray-500 flex items-center">
                          <Truck className="w-3 h-3 mr-1" />
                          {listing.delivery}
                        </div>
                      )}
                    </div>
                  </div>
                  <a 
                    href={listing.productUrl} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className={`px-4 py-2 rounded-md text-sm transition ${index === 0 ? 'bg-orange-500 hover:bg-orange-600 text-white' : 'border border-gray-200 hover:bg-gray-50 text-gray-700'}`}
                  >
                    {index === 0 ? 'Buy Now' : 'Visit'}
                  </a>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      
      {/* Product Details Tabs */}
      <div className="mt-12">
        <div className="border-b">
          <nav className="flex -mb-px">
            <button className="text-orange-500 border-orange-500 border-b-2 py-4 px-6 font-medium text-sm">
              Description
            </button>
            <button className="text-gray-500 hover:text-gray-700 py-4 px-6 font-medium text-sm">
              Specifications
            </button>
            <button className="text-gray-500 hover:text-gray-700 py-4 px-6 font-medium text-sm">
              Reviews ({product.reviews})
            </button>
          </nav>
        </div>
        
        <div className="py-6 prose max-w-none">
          <p>{product.description}</p>
        </div>
      </div>
    </div>
  );
};

export default ProductDetailsPage;