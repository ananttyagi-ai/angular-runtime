export interface Platform {
  id: string;
  name: string;
  logoUrl: string;
}