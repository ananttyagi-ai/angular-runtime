import { Platform } from './Platform';

export interface PriceListing {
  price: number;
  platform: Platform;
  productUrl: string;
  delivery?: string;
  inStock: boolean;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  images: string[];
  rating: number;
  reviews: number;
  mrp?: number; // Maximum Retail Price
  highlights: string[];
  priceListings: PriceListing[];
}