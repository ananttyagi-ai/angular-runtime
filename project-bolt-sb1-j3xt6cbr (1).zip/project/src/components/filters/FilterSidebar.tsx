import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { platforms } from '../../data/platforms';

interface FilterSidebarProps {
  activeFilters: {
    platforms: string[];
    priceRange: [number, number] | null;
    sortBy: string;
  };
  onApplyFilters: (filters: FilterSidebarProps['activeFilters']) => void;
  onClose: () => void;
}

const FilterSidebar: React.FC<FilterSidebarProps> = ({ 
  activeFilters, 
  onApplyFilters,
  onClose
}) => {
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>(activeFilters.platforms);
  const [priceRange, setPriceRange] = useState<[number, number] | null>(activeFilters.priceRange);
  const [minPrice, setMinPrice] = useState<string>(activeFilters.priceRange ? activeFilters.priceRange[0].toString() : '');
  const [maxPrice, setMaxPrice] = useState<string>(activeFilters.priceRange ? activeFilters.priceRange[1].toString() : '');
  const [sortBy, setSortBy] = useState<string>(activeFilters.sortBy);
  
  // Update local state when active filters change
  useEffect(() => {
    setSelectedPlatforms(activeFilters.platforms);
    setPriceRange(activeFilters.priceRange);
    setMinPrice(activeFilters.priceRange ? activeFilters.priceRange[0].toString() : '');
    setMaxPrice(activeFilters.priceRange ? activeFilters.priceRange[1].toString() : '');
    setSortBy(activeFilters.sortBy);
  }, [activeFilters]);
  
  // Handle platform selection
  const togglePlatform = (platformId: string) => {
    setSelectedPlatforms(prev => 
      prev.includes(platformId) 
        ? prev.filter(id => id !== platformId) 
        : [...prev, platformId]
    );
  };
  
  // Handle price range changes
  const handlePriceRangeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const min = Number(minPrice);
    const max = Number(maxPrice);
    
    if (isNaN(min) || isNaN(max)) {
      return;
    }
    
    if (min >= 0 && max > 0 && max >= min) {
      setPriceRange([min, max]);
    } else {
      setPriceRange(null);
      setMinPrice('');
      setMaxPrice('');
    }
  };

  // Clear price range
  const clearPriceRange = () => {
    setPriceRange(null);
    setMinPrice('');
    setMaxPrice('');
  };
  
  // Apply filters
  const applyFilters = () => {
    onApplyFilters({
      platforms: selectedPlatforms,
      priceRange,
      sortBy
    });
    
    // On mobile, close the sidebar after applying filters
    if (window.innerWidth < 768) {
      onClose();
    }
  };
  
  return (
    <div className="bg-white rounded-lg border p-4 sticky top-24">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-semibold text-lg">Filters</h2>
        <button 
          onClick={onClose}
          className="md:hidden text-gray-500 hover:text-gray-700"
          aria-label="Close filters"
        >
          <X className="w-5 h-5" />
        </button>
      </div>
      
      {/* Sort By */}
      <div className="mb-6">
        <h3 className="font-medium mb-3">Sort By</h3>
        <div className="space-y-2">
          {[
            { id: 'bestMatch', label: 'Best Match' },
            { id: 'priceLowToHigh', label: 'Price: Low to High' },
            { id: 'priceHighToLow', label: 'Price: High to Low' },
            { id: 'newest', label: 'Newest First' }
          ].map(option => (
            <label key={option.id} className="flex items-center">
              <input
                type="radio"
                name="sortBy"
                value={option.id}
                checked={sortBy === option.id}
                onChange={() => setSortBy(option.id)}
                className="w-4 h-4 text-orange-500 focus:ring-orange-500 border-gray-300"
              />
              <span className="ml-2 text-gray-700">{option.label}</span>
            </label>
          ))}
        </div>
      </div>
      
      {/* Price Range */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-medium">Price Range</h3>
          {priceRange && (
            <button 
              onClick={clearPriceRange}
              className="text-xs text-orange-500 hover:text-orange-600"
            >
              Clear
            </button>
          )}
        </div>
        
        <form onSubmit={handlePriceRangeSubmit} className="flex items-center gap-2">
          <div className="relative flex-1">
            <span className="absolute inset-y-0 left-2 flex items-center text-gray-500">₹</span>
            <input
              type="number"
              placeholder="Min"
              value={minPrice}
              onChange={e => setMinPrice(e.target.value)}
              min="0"
              className="block w-full pl-6 pr-2 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-orange-500 focus:border-orange-500"
            />
          </div>
          <span className="text-gray-400">to</span>
          <div className="relative flex-1">
            <span className="absolute inset-y-0 left-2 flex items-center text-gray-500">₹</span>
            <input
              type="number"
              placeholder="Max"
              value={maxPrice}
              onChange={e => setMaxPrice(e.target.value)}
              min="0"
              className="block w-full pl-6 pr-2 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-orange-500 focus:border-orange-500"
            />
          </div>
          <button
            type="submit"
            className="bg-gray-100 hover:bg-gray-200 text-gray-800 py-2 px-3 rounded text-sm"
          >
            Go
          </button>
        </form>
        
        {priceRange && (
          <div className="mt-2 text-sm text-gray-600">
            Selected: ₹{priceRange[0]} - ₹{priceRange[1]}
          </div>
        )}
      </div>
      
      {/* Platforms */}
      <div className="mb-6">
        <h3 className="font-medium mb-3">Platforms</h3>
        <div className="space-y-2 max-h-60 overflow-y-auto">
          {platforms.map(platform => (
            <label key={platform.id} className="flex items-center">
              <input
                type="checkbox"
                checked={selectedPlatforms.includes(platform.id)}
                onChange={() => togglePlatform(platform.id)}
                className="w-4 h-4 text-orange-500 focus:ring-orange-500 border-gray-300 rounded"
              />
              <span className="ml-2 flex items-center">
                <img src={platform.logoUrl} alt={platform.name} className="h-4 w-auto mr-2" />
                <span className="text-gray-700">{platform.name}</span>
              </span>
            </label>
          ))}
        </div>
      </div>
      
      {/* Apply Filters Button */}
      <button
        onClick={applyFilters}
        className="w-full py-2 px-4 bg-orange-500 hover:bg-orange-600 text-white rounded transition"
      >
        Apply Filters
      </button>
    </div>
  );
};

export default FilterSidebar;