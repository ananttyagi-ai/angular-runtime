import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingBag, Mail, Phone, MapPin, Facebook, Twitter, Instagram, Linkedin } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="container mx-auto px-4 py-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand Information */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <ShoppingBag className="w-8 h-8 text-orange-500" />
              <span className="font-bold text-xl text-white">
                India<span className="text-orange-500">Shop</span>Hub
              </span>
            </div>
            <p className="text-sm opacity-75">
              Compare prices across all major Indian e-commerce platforms in one place.
              Find the best deals and save money on your online shopping.
            </p>
            <div className="flex space-x-4 pt-2">
              <a href="#" className="text-gray-400 hover:text-orange-500 transition">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-orange-500 transition">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-orange-500 transition">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-orange-500 transition">
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-white">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="opacity-75 hover:opacity-100 hover:text-orange-500 transition">Home</Link>
              </li>
              <li>
                <Link to="/wishlist" className="opacity-75 hover:opacity-100 hover:text-orange-500 transition">My Wishlist</Link>
              </li>
              <li>
                <a href="#" className="opacity-75 hover:opacity-100 hover:text-orange-500 transition">About Us</a>
              </li>
              <li>
                <a href="#" className="opacity-75 hover:opacity-100 hover:text-orange-500 transition">Contact Us</a>
              </li>
              <li>
                <a href="#" className="opacity-75 hover:opacity-100 hover:text-orange-500 transition">Terms & Conditions</a>
              </li>
              <li>
                <a href="#" className="opacity-75 hover:opacity-100 hover:text-orange-500 transition">Privacy Policy</a>
              </li>
            </ul>
          </div>

          {/* Supported Platforms */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-white">Supported Platforms</h3>
            <ul className="space-y-2">
              <li className="opacity-75 hover:opacity-100 hover:text-orange-500 transition">Amazon India</li>
              <li className="opacity-75 hover:opacity-100 hover:text-orange-500 transition">Flipkart</li>
              <li className="opacity-75 hover:opacity-100 hover:text-orange-500 transition">Myntra</li>
              <li className="opacity-75 hover:opacity-100 hover:text-orange-500 transition">Meesho</li>
              <li className="opacity-75 hover:opacity-100 hover:text-orange-500 transition">Snapdeal</li>
              <li className="opacity-75 hover:opacity-100 hover:text-orange-500 transition">Ajio</li>
            </ul>
          </div>

          {/* Contact Information */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-white">Contact Us</h3>
            <ul className="space-y-4">
              <li className="flex items-start space-x-3">
                <MapPin className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                <span className="opacity-75">123 Tech Park, Bangalore, Karnataka 560001, India</span>
              </li>
              <li className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-orange-500 flex-shrink-0" />
                <span className="opacity-75">+91 9876543210</span>
              </li>
              <li className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-orange-500 flex-shrink-0" />
                <span className="opacity-75">support@indiashophub.com</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-gray-800 mt-10 pt-6 text-center text-sm opacity-75">
          <p>&copy; {new Date().getFullYear()} IndiaShopHub. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;