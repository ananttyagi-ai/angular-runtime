import React from 'react';
import { Link } from 'react-router-dom';
import { Star, ExternalLink } from 'lucide-react';
import { Product } from '../../types/Product';

interface PriceComparisonCardProps {
  product: Product;
}

const PriceComparisonCard: React.FC<PriceComparisonCardProps> = ({ product }) => {
  // Sort price listings by price (lowest first)
  const sortedPriceListings = [...product.priceListings].sort((a, b) => a.price - b.price);
  const lowestPrice = sortedPriceListings[0];
  
  // Calculate price difference between lowest and highest
  const highestPrice = sortedPriceListings[sortedPriceListings.length - 1];
  const priceDifference = highestPrice.price - lowestPrice.price;
  const savingsPercentage = Math.round((priceDifference / highestPrice.price) * 100);
  
  return (
    <div className="bg-white rounded-lg shadow-sm border hover:shadow-md transition overflow-hidden">
      <div className="p-4 md:p-6">
        <div className="flex flex-col md:flex-row">
          {/* Product Image */}
          <Link 
            to={`/product/${product.id}`} 
            className="md:w-48 lg:w-56 flex-shrink-0 mb-4 md:mb-0 md:mr-6"
          >
            <div className="aspect-square overflow-hidden rounded-md bg-gray-100">
              <img 
                src={product.images[0]} 
                alt={product.name} 
                className="w-full h-full object-contain hover:scale-105 transition duration-300" 
              />
            </div>
          </Link>
          
          {/* Product Info */}
          <div className="flex-grow flex flex-col">
            <div className="flex-grow">
              <Link to={`/product/${product.id}`} className="inline-block">
                <h2 className="text-lg font-semibold mb-2 hover:text-orange-500 transition">
                  {product.name}
                </h2>
              </Link>
              
              <div className="flex items-center mb-3">
                <div className="flex items-center">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star 
                      key={i} 
                      className={`w-4 h-4 ${i < Math.floor(product.rating) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
                    />
                  ))}
                  <span className="ml-1 text-sm text-gray-600">{product.rating.toFixed(1)}</span>
                </div>
                <span className="text-sm text-gray-500 ml-2">({product.reviews} reviews)</span>
              </div>
              
              {/* Key highlights */}
              {product.highlights && product.highlights.length > 0 && (
                <ul className="text-sm text-gray-600 mb-4 space-y-1">
                  {product.highlights.slice(0, 3).map((highlight, index) => (
                    <li key={index} className="flex items-baseline">
                      <span className="w-1 h-1 bg-gray-400 rounded-full mr-2 mt-1.5 flex-shrink-0"></span>
                      <span className="line-clamp-1">{highlight}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
            
            {/* Price Comparison Section */}
            <div className="mt-3 pt-3 border-t">
              <div className="flex flex-col sm:flex-row sm:items-end justify-between">
                <div>
                  <div className="text-sm font-medium text-gray-500 mb-1">Price Comparison</div>
                  <div className="flex items-baseline">
                    <span className="text-xl font-bold text-gray-900">₹{lowestPrice.price.toLocaleString()}</span>
                    {product.mrp && (
                      <>
                        <span className="ml-2 text-sm text-gray-500 line-through">₹{product.mrp.toLocaleString()}</span>
                        <span className="ml-2 text-sm font-medium text-green-600">
                          {Math.round(((product.mrp - lowestPrice.price) / product.mrp) * 100)}% off
                        </span>
                      </>
                    )}
                  </div>
                  {savingsPercentage > 0 && (
                    <p className="text-xs text-green-600 mt-1">
                      Save up to {savingsPercentage}% compared to other sellers
                    </p>
                  )}
                </div>
                
                <Link 
                  to={`/product/${product.id}`} 
                  className="mt-3 sm:mt-0 text-orange-500 hover:text-orange-600 text-sm font-medium"
                >
                  View Details
                </Link>
              </div>
              
              {/* Platform price comparison */}
              <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                {sortedPriceListings.slice(0, 3).map((listing, index) => (
                  <a 
                    key={index}
                    href={listing.productUrl} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className={`flex items-center justify-between p-2 rounded border ${index === 0 ? 'bg-orange-50 border-orange-100' : 'bg-gray-50 border-gray-100'} hover:bg-gray-100 transition`}
                  >
                    <div className="flex items-center gap-2">
                      <img 
                        src={listing.platform.logoUrl} 
                        alt={listing.platform.name} 
                        className="h-5 w-auto" 
                      />
                      <span className="font-medium">₹{listing.price.toLocaleString()}</span>
                    </div>
                    <ExternalLink className="w-4 h-4 text-gray-400" />
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PriceComparisonCard;