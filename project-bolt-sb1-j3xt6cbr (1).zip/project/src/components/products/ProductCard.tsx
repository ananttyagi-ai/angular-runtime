import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, Star } from 'lucide-react';
import { Product } from '../../types/Product';
import { useWishlist } from '../../context/WishlistContext';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();
  const inWishlist = isInWishlist(product.id);
  
  const toggleWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (inWishlist) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist(product);
    }
  };
  
  // Get the lowest price from all platforms
  const lowestPrice = product.priceListings.reduce(
    (min, listing) => (listing.price < min.price ? listing : min),
    product.priceListings[0]
  );

  return (
    <Link 
      to={`/product/${product.id}`} 
      className="group block bg-white rounded-lg shadow-sm border hover:shadow-md transition overflow-hidden"
    >
      {/* Product Image */}
      <div className="relative aspect-square overflow-hidden bg-gray-100">
        <img 
          src={product.images[0]} 
          alt={product.name} 
          className="w-full h-full object-contain group-hover:scale-105 transition duration-300" 
        />
        
        {/* Wishlist button */}
        <button
          onClick={toggleWishlist}
          className={`absolute top-2 right-2 p-2 rounded-full ${
            inWishlist 
              ? 'bg-red-50 text-red-500' 
              : 'bg-white/80 text-gray-500 hover:text-red-500'
          } transition`}
          aria-label={inWishlist ? "Remove from wishlist" : "Add to wishlist"}
        >
          <Heart className={`w-5 h-5 ${inWishlist ? 'fill-red-500' : ''}`} />
        </button>
        
        {/* Discount badge - show only if product has MRP */}
        {product.mrp && (
          <div className="absolute top-2 left-2 bg-green-500 text-white text-xs font-bold px-2 py-1 rounded">
            {Math.round(((product.mrp - lowestPrice.price) / product.mrp) * 100)}% OFF
          </div>
        )}
      </div>
      
      {/* Product Info */}
      <div className="p-4">
        <h3 className="font-medium text-gray-900 mb-1 line-clamp-2 group-hover:text-orange-500 transition">
          {product.name}
        </h3>
        
        <div className="flex items-center mb-2">
          <div className="flex items-center">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star 
                key={i} 
                className={`w-3 h-3 ${i < Math.floor(product.rating) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
              />
            ))}
          </div>
          <span className="text-xs text-gray-500 ml-1">({product.reviews})</span>
        </div>
        
        <div className="mt-2 flex items-center justify-between">
          <div>
            <div className="flex items-baseline">
              <span className="text-lg font-bold text-gray-900">₹{lowestPrice.price.toLocaleString()}</span>
              {product.mrp && (
                <span className="ml-2 text-sm text-gray-500 line-through">₹{product.mrp.toLocaleString()}</span>
              )}
            </div>
            <div className="mt-1 flex items-center">
              <img 
                src={lowestPrice.platform.logoUrl} 
                alt={lowestPrice.platform.name} 
                className="h-4 w-auto mr-1" 
              />
              <span className="text-xs text-gray-600">+ {product.priceListings.length - 1} more</span>
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default ProductCard;