import { Product } from '../types/Product';
import { trendingProducts } from '../data/mockProducts';

interface SearchFilters {
  platforms: string[];
  priceRange: [number, number] | null;
  sortBy: string;
}

// Simulate API call to search products
export const searchProducts = (query: string, filters?: SearchFilters): Promise<Product[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      // Filter products based on search query
      let results = [...trendingProducts];
      
      if (query) {
        results = results.filter(product => 
          product.name.toLowerCase().includes(query.toLowerCase()) ||
          product.description.toLowerCase().includes(query.toLowerCase())
        );
      }
      
      // Apply platform filters
      if (filters?.platforms.length) {
        results = results.filter(product => 
          product.priceListings.some(listing => 
            filters.platforms.includes(listing.platform.id)
          )
        );
      }
      
      // Apply price range filters
      if (filters?.priceRange) {
        const [min, max] = filters.priceRange;
        results = results.filter(product => {
          const lowestPrice = Math.min(...product.priceListings.map(listing => listing.price));
          return lowestPrice >= min && lowestPrice <= max;
        });
      }
      
      // Apply sorting
      if (filters?.sortBy) {
        switch (filters.sortBy) {
          case 'priceLowToHigh':
            results.sort((a, b) => {
              const aPrice = Math.min(...a.priceListings.map(listing => listing.price));
              const bPrice = Math.min(...b.priceListings.map(listing => listing.price));
              return aPrice - bPrice;
            });
            break;
            
          case 'priceHighToLow':
            results.sort((a, b) => {
              const aPrice = Math.min(...a.priceListings.map(listing => listing.price));
              const bPrice = Math.min(...b.priceListings.map(listing => listing.price));
              return bPrice - aPrice;
            });
            break;
            
          case 'newest':
            // In a real app, we would sort by date added
            // Here we're just randomizing for demonstration
            results.sort(() => Math.random() - 0.5);
            break;
            
          default:
            // 'bestMatch' - no specific sorting, use default
            break;
        }
      }
      
      resolve(results);
    }, 800); // Simulate network delay
  });
};

// Simulate API call to get product by ID
export const getProductById = (id: string): Promise<Product> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const product = trendingProducts.find(p => p.id === id);
      
      if (product) {
        resolve(product);
      } else {
        reject(new Error('Product not found'));
      }
    }, 500);
  });
};